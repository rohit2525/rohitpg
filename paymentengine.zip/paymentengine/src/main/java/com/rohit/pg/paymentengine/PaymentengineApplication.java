package com.rohit.pg.paymentengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentengineApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentengineApplication.class, args);
	}

}
